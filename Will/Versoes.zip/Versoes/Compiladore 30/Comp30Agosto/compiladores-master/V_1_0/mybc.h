/**@<mybc.h>::**/

extern int gettoken(FILE *);

extern void expr(void);
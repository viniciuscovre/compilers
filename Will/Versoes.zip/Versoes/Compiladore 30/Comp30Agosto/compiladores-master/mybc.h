/**@<mybc.h>::**/

extern int gettoken(FILE *);

extern void mybc(void);

extern void expr(void);

extern void init(void);

extern void printa_tabela(void);
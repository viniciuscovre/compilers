/**@<mybc.h>::**/

extern int gettoken(FILE *);

extern void mybc(void);
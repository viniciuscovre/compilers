/**@<parser.c>::**/

#include <stdio.h>
#include <stdlib.h>
#include <parser.h>
#include <tokens.h>
#include <lexer.h>


/*************************** LL(1) grammar definition ******************************
 *(comentario pf = pos fixa)
 * 
 * expr -> term {addop term} || expr.pf :=term.pf{ term.pf addop.pf }
 *
 * term -> fact {mulop fact} || term.pf := fact.pf { fact.pf mulop.pf }
 * 
 * fact -> vrbl | cons | ( expr ) || expr.pf
 * 
 * //RETIRADO rest -> addop term rest | <>
 * //RETIRADO quoc -> mulop fact quoc | <>
 *
 * vrbl -> ID
 *
 * cons -> DEC
 *
 * addop -> '+' | '-'
 *
 * mulop -> '*' | '/'
 *
 * ID = [A-Za-z][A-Za-z0-9]*
 *
 * DEC = [1-9][0-9]* | 0
 *
 **********************************************************************************/

/***************************** LL(1) grammar emulation *******************************/
/*
 * 
 *	source language		||	object language 
 * expr -> term { addop term } 	|| expr.pf :=term.pf{ term.pf addop.pf }
 * -----------------------------------------------------------------------------------
 * expr -> term { addop term [[ printf(addop.pf); ]] }
 * (comentario: ação semantica é o que esta entre colchetes, regra semanatica é a linha abaixo do source language e object language)
 *
 *
 *
 *
 * o que esta com frescura é ação semantica
 */
void expr (void)
{
	/**/ int op/**/;
	term(); 
	while( op = addop() ){ term();/**/printf("%c ",op)/**/;}
}


/*
 * term -> fact { mulop fact } || term.pf := fact.pf { fact.pf mulop.pf }*/
void term (void)
{
	/**/ int op/**/;
	fact(); 
	while(mulop()){fact();/**/printf("%c ",op)/**/;}
}

/*
 * fact -> vrbl | cons | ( expr ) */
void fact (void)
{
	switch (lookahead) {
	case ID:
		/**/printf("%s ", lexeme)/**/;  match (ID);break;
	case DEC:
		/**/printf("decimal ")/**/;match (DEC); break;
	default:
		match ('('); expr(); match (')'); /* || expŕ.pf
	}
}
/*
 * vrbl -> ID
 *
 * cons -> DEC
*
 * ID = [A-Za-z][A-Za-z0-9]*
 *
 * DEC = [1-9][0-9]* | 0
 *
 * addop -> '+' | '-' */
int addop (void)
{
	switch(lookahead){
	case '+':
			match('+'); return '+';
	case '-': 
			match('-'); return '-';
	}

	return 0;
}

/*
 * mulop -> '*' | '/' */
int mulop (void)
{
	switch(lookahead){
	case '*':
			match('*'); return '*';
	case '/': 
			match('/'); return '/';
	}
	return 0;
}
/***************************** lexer-to-parser interface **************************/

int lookahead; // @ local

void match (int expected)
 {
	 if ( expected == lookahead) {
		 lookahead = gettoken (source);
	 } else {
		 fprintf(stderr,"parser: token mismatch error. found # %d ",
		 	lookahead);
		 fprintf(stderr,"whereas expected # %d\n",
		 	expected);
		 exit (SYNTAX_ERR);
	 }
 }


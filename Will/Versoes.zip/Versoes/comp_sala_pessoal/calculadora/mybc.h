/**@<mybc.h>::**/

extern int gettoken(FILE *);

extern int expr();
#include <stdio.h>
#include <stdlib.h>

#define FLT 2

//(int'.'digit* | '.'digit*)

int scanfloat(FILE *tape)
{
	int head = getc(tape);
	if ( head == '0')
		{
		head = getc(tape);
		if (head == '.')
			{
			head = getc(tape);	
			if (head >= '0' && head <= '9')
				{
				while ( (head = getc(tape)) >= '0' && head <= '9');
				if(head = getc(tape)!=EOF)
					printf("nao eh float 1 \n");
				else
					printf("eh float a\n");
				ungetc(head,tape);
				return FLT;
				}
			else
				{
				ungetc(head,tape);
				printf("nao eh float 2\n");
				}
			}
		else
			{
			ungetc(head,tape);
			printf("nao eh float 3\n");
			}
		}
	else if (head == '.')
			{	
			head = getc(tape);
			if (head >= '0' && head <= '9')
				{
				while ( (head = getc(tape)) >= '0' && head <= '9');
				if(head = getc(tape)!=EOF)
					printf("nao eh float 4\n");
				else
					printf("eh float b\n");
				ungetc(head,tape);
				return FLT;
				}
			else
				{
				ungetc(head,tape);
				printf("nao eh float 5\n");
				}
			}
	else
		{
		ungetc(head,tape);
		printf("nao eh float 6\n");
		}
		
}

main (int argc, char *argv[], char *envp[])
{
	FILE *buffer;

	if (argc == 1) {
		buffer = stdin;
	} else {
		buffer = fopen (argv[1], "r");
		if (buffer == NULL) {
			fprintf (stderr, "%s: cannot open %s... exiting\n",
				argv[0], argv[1]);
			exit (-1);
		}
	}

	scanfloat(buffer);
	exit (0);

}

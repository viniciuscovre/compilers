#include <stdio.h>
#include <stdlib.h>

#define HEX 3

int scanhex(FILE *tape)
{
	int head = getc(tape);
	if ( head == '0')
		{
		head = getc(tape);
		if (head =='x')
			{
			if ( ((head = getc(tape)) >= '0' && head <= '9') || (head >= 'a' && head <= 'f') || (head >= 'A' && head <= 'F') )
				{
				while ( ((head = getc(tape)) >= '0' && head <= '9') || (head >= 'a' && head <= 'f') || (head >= 'A' && head <= 'F') );
				if(head = getc(tape)!=EOF)
					printf("nao eh hex\n");
				else
					printf("eh hex\n");
				ungetc(head,tape);
				return HEX;
				}
			else
				{
				ungetc(head,tape);
				printf("nao eh hex\n");
				}
			}
		else
			{
			ungetc(head,tape);
			printf("nao eh hex\n");
			}
		}
	else
		{
		ungetc(head,tape);
		printf("nao eh hex\n");
		}
}

main (int argc, char *argv[], char *envp[])
{
	FILE *buffer;

	if (argc == 1) {
		buffer = stdin;
	} else {
		buffer = fopen (argv[1], "r");
		if (buffer == NULL) {
			fprintf (stderr, "%s: cannot open %s... exiting\n",
				argv[0], argv[1]);
			exit (-1);
		}
	}

	scanhex(buffer);	

	exit (0);

}

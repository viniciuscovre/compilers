#include <stdio.h>
#include <stdlib.h>

#define OCT 1
// 0[0-7]*

int scanoct(FILE *tape)
{
	int head = getc(tape);
	if ( head == '0')
		{
		head = getc(tape);
		if (head >= '0' && head <= '7')
			{
			while ( (head = getc(tape)) >= '0' && head <= '7');
			if(head = getc(tape)!=EOF)
				printf("nao eh octal\n");
			else
				printf("eh octal\n");
			ungetc(head,tape);
			return OCT;
			}
		else
			{
			ungetc(head,tape);
			printf("nao eh octal\n");
			}
		}
	else
		{
		ungetc(head,tape);
		printf("nao eh octal\n");
		}
		
}

main (int argc, char *argv[], char *envp[])
{
	FILE *buffer;

	if (argc == 1) {
		buffer = stdin;
	} else {
		buffer = fopen (argv[1], "r");
		if (buffer == NULL) {
			fprintf (stderr, "%s: cannot open %s... exiting\n",
				argv[0], argv[1]);
			exit (-1);
		}
	}

	scanoct(buffer);
	exit (0);

}

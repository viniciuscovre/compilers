/**@<mybc.h>::**/

extern int gettoken(FILE *);

extern void expr(void);

extern void init();

extern void match();



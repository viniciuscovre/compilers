#include <stdio.h>
#include <stdlib.h>

#define ID 5
#define DEC 2
#define FLT 3
#define HEX 4
#define OCT 1

//(int'.'digit* | '.'digit*)

int scanfloat(FILE *tape)
{
	int head = getc(tape);
	if ( head == '0')
		{
		head = getc(tape);
		if (head == '.')
			{
			head = getc(tape);	
			if (head >= '0' && head <= '9')
				{
				while ( (head = getc(tape)) >= '0' && head <= '9');
				if(head = getc(tape)==EOF)
					printf("eh float a\n");
				ungetc(head,tape);
				return FLT;
				}
			else
				{
				ungetc(head,tape);
				}
			}
		else
			{
			ungetc(head,tape);
			}
		}
	else if (head == '.')
			{	
			head = getc(tape);
			if (head >= '0' && head <= '9')
				{
				while ( (head = getc(tape)) >= '0' && head <= '9');
				if(head = getc(tape)==EOF)
					printf("eh float b\n");
				ungetc(head,tape);
				return FLT;
				}
			else
				{
				ungetc(head,tape);
				}
			}
	else
		{
		ungetc(head,tape);
		}
	return 0;		
}

int scandec(FILE *tape)
{
	int head = getc(tape);
	if (head >= '0' && head <= '9') {
		if (head == '0') {
			return DEC;
		}
		// [0-9]*
		while ( (head = getc(tape)) >= '0' && head <= '9');
		if(head = getc(tape)==EOF)
					printf("eh dec\n");
		ungetc(head,tape);
		return DEC;
	}
	return 0;
}

int scanhex(FILE *tape)
{
	int head = getc(tape);
	int head_aux;
	if ( head == '0')
		{
		head_aux = head;
		head = getc(tape);
		if (head =='x')
			{
			if ( ((head = getc(tape)) >= '0' && head <= '9') || (head >= 'a' && head <= 'f') || (head >= 'A' && head <= 'F') )
				{
				while ( ((head = getc(tape)) >= '0' && head <= '9') || (head >= 'a' && head <= 'f') || (head >= 'A' && head <= 'F') );
				if(head = getc(tape)==EOF)
					printf("eh hex\n");
				ungetc(head,tape);
				return HEX;
				}
			else
				{
				return ID;
				}
			}
		else
			{
			ungetc(head_aux,tape);
			ungetc(head,tape);
			//printf("nao eh hex\n");
			}
		}
	else
		{
		ungetc(head,tape);
		//printf("nao eh hex\n");
		}

	return 0;
}

int scanoct(FILE *tape)
{
	int head = getc(tape);
	if ( head == '0')
		{
		head = getc(tape);
		if (head >= '0' && head <= '7')
			{
			while ( (head = getc(tape)) >= '0' && head <= '7');
			if(head = getc(tape)==EOF)
				printf("eh octal\n");
			ungetc(head,tape);
			return OCT;
			}
		else
			{
			ungetc(head,tape);
			//printf("nao eh octal\n");
			}
		}
	else
		{
		ungetc(head,tape);
		//printf("nao eh octal\n");
		}
		return 0;
}


main (int argc, char *argv[], char *envp[])
{
	FILE *buffer;

	if (argc == 1) {
		buffer = stdin;
	} else {
		buffer = fopen (argv[1], "r");
		if (buffer == NULL) {
			fprintf (stderr, "%s: cannot open %s... exiting\n",
				argv[0], argv[1]);
			exit (-1);
		}
	}

	if (scanoct(buffer)==OCT)
        printf("string is an octal\n");
    else if (scanhex(buffer)==HEX || scanhex(buffer)==ID)
		if(scanhex(buffer)==HEX)
        	printf("string is a hexadecimal\n");
		else if (scanhex(buffer)==ID)
			printf("string is not a number\n");
    else if (scandec(buffer)==DEC)
        printf("string is a decimal\n");
     else if(scanfloat(buffer)==FLT)
        printf("string is a float\n");
      else
        printf("string is not a number\n");

	exit (0);

}




